-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jan 25, 2023 at 11:42 AM
-- Server version: 10.4.25-MariaDB
-- PHP Version: 8.1.10

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `ecomerce`
--

-- --------------------------------------------------------

--
-- Table structure for table `banner`
--

CREATE TABLE `banner` (
  `id` int(11) NOT NULL,
  `titulo` varchar(50) DEFAULT 'Gtwork Electronics',
  `descricao` varchar(300) DEFAULT 'Computation and electronics of Gtwork',
  `imgBanner` varchar(100) DEFAULT NULL,
  `estado` enum('activado','desativado') DEFAULT 'desativado',
  `alterar` enum('First slide','Second slide','Third slide') DEFAULT 'Third slide'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `banner`
--

INSERT INTO `banner` (`id`, `titulo`, `descricao`, `imgBanner`, `estado`, `alterar`) VALUES
(13, 'Makup', 'sgjdhfgbukjfbues', '63d1026a2cbe5b.png', 'activado', 'Third slide'),
(14, 'Maria', 'njkdfnki', '63d1030d5e9efb.jpg', 'activado', 'Third slide');

-- --------------------------------------------------------

--
-- Table structure for table `categoria`
--

CREATE TABLE `categoria` (
  `id` int(11) NOT NULL,
  `categoria` varchar(90) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `categoria`
--

INSERT INTO `categoria` (`id`, `categoria`) VALUES
(1, 'Peruca'),
(2, 'Bases'),
(3, 'Maqueagem'),
(4, 'Baton'),
(5, 'Cero');

-- --------------------------------------------------------

--
-- Table structure for table `cliente`
--

CREATE TABLE `cliente` (
  `idCliente` int(11) NOT NULL,
  `id` int(11) NOT NULL,
  `Pnome` varchar(80) DEFAULT NULL,
  `Unome` varchar(30) NOT NULL,
  `pais` varchar(50) DEFAULT 'Angola',
  `Nempresa` varchar(70) NOT NULL,
  `endereco` varchar(90) NOT NULL,
  `cidade` varchar(70) NOT NULL,
  `condado` varchar(80) NOT NULL,
  `cep` varchar(89) NOT NULL,
  `email` varchar(80) NOT NULL,
  `telefone` varchar(80) NOT NULL,
  `produtos` varchar(600) DEFAULT NULL,
  `preco` varchar(300) DEFAULT NULL,
  `qtd` varchar(200) DEFAULT NULL,
  `total` float DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `cliente`
--

INSERT INTO `cliente` (`idCliente`, `id`, `Pnome`, `Unome`, `pais`, `Nempresa`, `endereco`, `cidade`, `condado`, `cep`, `email`, `telefone`, `produtos`, `preco`, `qtd`, `total`) VALUES
(1, 3, 'Abraao', 'Castelo', 'AO', 'Gtwork', 'Vuana/estalagem', 'Luanda', 'Angola', '6684556', 'abraaocastelo14@gmail.com', '944029977', ',Tv plasma LG', '140000', ',10', 140000),
(2, 3, 'Moisana', 'Castelo', 'AO', 'Gtwork', 'Vuana/estalagem', '', '', '', '', '', ',Tv plasma LG', '140000', ',10', 140000),
(3, 3, 'Paula', 'Castelo', 'AO', 'Primogenito', 'Km 14A', 'Luanda', 'Angola', '3456765', 'abraaocastelo14@gmail.com', '932292101', ',TECNO SPARK 3', '65000', ',15', 65000),
(4, 30, 'Florencia', 'guda', 'AO', 'Makeup', 'viana', 'LUANDA', 'ANGOLA', '4324243', 'florencia@gmail.com', '', ',gel', '2500', ',3', 2500),
(5, 30, 'Florencia', 'guda', 'DZ', 'gtwork', 'Viana', 'luanda', '', '2232132', 'root', '0922340091', ',serum', '8000', ',3', 8000),
(6, 3, '', '', 'AO', '', '', '', '', '', 'root', '', '', '', '', 0),
(7, 3, 'gel', 'sdf', 'AO', 'makeup', 'viana', 'luanda', 'ANGOLA', '', 'root', '930326154', '', '', '', 0),
(8, 3, 'Florencia', 'guda', 'AO', 'Makeup', 'viana', 'LUANDA', 'ANGOLA', '', 'root', '', '', '', '', 0),
(9, 3, 'Florencia', 'jota', 'AO', 'Makeup', 'viana', 'LUANDA', 'ANGOLA', '', 'florencia@gmail.com', '930326154', '', '', '', 0),
(10, 3, 'flora', 'mateus', 'AO', 'atelier', 'Luanda/Talatona rua direita de SIAC', 'Luanda', 'Angola', '12345', 'florencia@gmail.com', '926153108', ',pinceis', '5000', ',1', 5000),
(11, 3, 'flora', 'mateus', 'AO', 'atelier', 'Luanda/Talatona rua direita de SIAC', 'Luanda', 'Angola', '12345', 'eluckimossi@gmail.com', '926153108', '', '', '', 0),
(12, 3, 'flora', 'mateus', 'AO', 'atelier', 'Luanda/Talatona rua direita de SIAC', 'Luanda', 'Angola', '2345', 'eluckimossi@gmail.com', '926153108', ',pinceis', '5000', ',1', 5000),
(13, 3, 'fernanda', 'prazer', 'AO', 'maquiagem', 'Luanda/Talatona rua direita de SIAC', 'Luanda', 'Angola', '12345', 'eluckimossi@gmail.com', '926153108', '', '', '', 0),
(14, 3, 'Eluki', 'Nelo', 'AO', 'Maquiagem', 'Talatona', 'Luanda', 'Angola', '108920700ZE0413', 'fernanda@gmail.com', '926153108', ',piruca', '40000', ',1', 40000);

-- --------------------------------------------------------

--
-- Table structure for table `detalhesproduct`
--

CREATE TABLE `detalhesproduct` (
  `idPedido` int(11) DEFAULT NULL,
  `produto` varchar(600) DEFAULT NULL,
  `preco` varchar(300) DEFAULT NULL,
  `qtd` varchar(200) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `pedido`
--

CREATE TABLE `pedido` (
  `id` int(11) NOT NULL,
  `idCliente` int(11) DEFAULT NULL,
  `idFuncionario` int(11) DEFAULT NULL,
  `data_pedido` datetime DEFAULT NULL,
  `data_necessaria` datetime DEFAULT NULL,
  `data_envio` date DEFAULT NULL,
  `via_maritima` enum('sim','nao') DEFAULT 'nao',
  `frete` enum('sim','nao') DEFAULT 'nao',
  `nome_navio` enum('sim','nao') DEFAULT 'nao',
  `endereco_navio` enum('sim','nao') DEFAULT 'nao',
  `modo_entrega` varchar(90) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `pedido`
--

INSERT INTO `pedido` (`id`, `idCliente`, `idFuncionario`, `data_pedido`, `data_necessaria`, `data_envio`, `via_maritima`, `frete`, `nome_navio`, `endereco_navio`, `modo_entrega`) VALUES
(1, 1, NULL, NULL, NULL, NULL, 'nao', 'nao', 'nao', 'nao', NULL),
(3, 2, NULL, NULL, NULL, NULL, 'nao', 'nao', 'nao', 'nao', NULL),
(4, 3, NULL, NULL, NULL, NULL, 'nao', 'nao', 'nao', 'nao', NULL),
(8, 4, NULL, NULL, NULL, NULL, 'nao', 'nao', 'nao', 'nao', NULL),
(13, 5, NULL, NULL, NULL, NULL, 'nao', 'nao', 'nao', 'nao', NULL),
(17, 6, NULL, NULL, NULL, NULL, 'nao', 'nao', 'nao', 'nao', NULL),
(24, 7, NULL, NULL, NULL, NULL, 'nao', 'nao', 'nao', 'nao', NULL),
(32, 8, NULL, NULL, NULL, NULL, 'nao', 'nao', 'nao', 'nao', NULL),
(41, 9, NULL, NULL, NULL, NULL, 'nao', 'nao', 'nao', 'nao', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `produtos`
--

CREATE TABLE `produtos` (
  `id` int(11) NOT NULL,
  `nome` varchar(90) DEFAULT NULL,
  `precoUnitario` float DEFAULT NULL,
  `qtd` int(11) DEFAULT NULL,
  `estado` varchar(90) DEFAULT NULL,
  `status` int(11) DEFAULT 1,
  `supplid` int(11) DEFAULT NULL,
  `idCategoria` int(11) DEFAULT NULL,
  `descricao` varchar(289) DEFAULT NULL,
  `imagem` varchar(90) DEFAULT NULL,
  `data` datetime DEFAULT NULL,
  `total` float DEFAULT NULL,
  `visivel` enum('sim','nao') DEFAULT 'sim'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `produtos`
--

INSERT INTO `produtos` (`id`, `nome`, `precoUnitario`, `qtd`, `estado`, `status`, `supplid`, `idCategoria`, `descricao`, `imagem`, `data`, `total`, `visivel`) VALUES
(18, 'Base', 3000, 44, 'stock', 1, 12345, 2, 'base de cor negra jebfu', '6398844ee547c', '2022-12-13 14:55:26', 132000, 'sim'),
(19, 'contorno', 4000, 2, 'stock', 1, 1234, 3, 'contorno para pele negra', '6398ec5c05ec5', '2022-12-13 22:19:24', 8000, 'sim'),
(20, 'piruca', 40000, 3, 'stock', 1, 1234, 1, 'piruca cacheada com front', '6398eff6b55fc', '2022-12-13 22:34:46', 160000, 'sim'),
(21, 'pinceis', 5000, 2, 'stock', 1, 12345, 3, 'pinceis para delineado', '6398f040e71c1', '2022-12-13 22:36:00', 20000, 'sim'),
(22, 'serum', 8000, 0, 'stock', 1, 5678, 3, 'cerum para rostos', '6398f09012aaf', '2022-12-13 22:37:20', 24000, 'sim'),
(23, 'gel', 2500, 0, 'stock', 1, 6789, 3, 'gel para sombracelhas', '6398f1209773f', '2022-12-13 22:39:44', 7500, 'sim');

-- --------------------------------------------------------

--
-- Table structure for table `usuarios`
--

CREATE TABLE `usuarios` (
  `id` int(11) NOT NULL,
  `nome` varchar(90) DEFAULT NULL,
  `email` varchar(90) DEFAULT NULL,
  `password` varchar(90) DEFAULT NULL,
  `permissao` enum('admin','cliente','gerente') DEFAULT 'cliente'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `usuarios`
--

INSERT INTO `usuarios` (`id`, `nome`, `email`, `password`, `permissao`) VALUES
(3, 'Ezequiel Chiemba', 'ezequiel@gmail.com', '142000', 'cliente'),
(30, 'Florencia Fernanda', 'florencia@gmail.com', '123456', 'admin'),
(31, 'Mach', 'mateuschiemba@hotmail.com', '123456', 'cliente'),
(32, 'mateus@gmail.com', 'mateus@gmail.com', '123', 'cliente'),
(33, 'kjhgfdhjjhgff', 'aaaaa@gmail.com', '12345', 'cliente'),
(34, 'luciana', 'luci@gmail.com', '12345', 'cliente'),
(35, 'Lito', 'lito@gmail.com', '567', 'cliente'),
(36, 'sousa', 'sousa@gmail.com', '123', 'cliente');

-- --------------------------------------------------------

--
-- Table structure for table `venda`
--

CREATE TABLE `venda` (
  `idVenda` int(11) NOT NULL,
  `produto` varchar(100) NOT NULL,
  `preco` float NOT NULL,
  `data` date NOT NULL,
  `qtd` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `venda`
--

INSERT INTO `venda` (`idVenda`, `produto`, `preco`, `data`, `qtd`) VALUES
(1, 'gel', 3000, '2022-12-06', 5),
(2, 'gel', 3000, '2022-12-12', 6),
(3, 'base', 3000, '2022-12-06', 4),
(4, 'base', 3000, '2022-12-12', 2),
(5, 'serum', 8000, '2022-12-06', 20),
(8, 'piruca', 5000, '0000-00-00', 2),
(9, '\"pincel\"', 5000, '0000-00-00', 2),
(10, 'pincel', 5000, '0000-00-00', 2),
(11, 'serum', 4000, '2010-02-23', 4),
(12, 'bases', 3000, '0000-00-00', 2),
(13, 'bases', 3000, '2010-02-23', 4),
(14, 'contorno', 4000, '2013-02-23', 2),
(15, 'Piruca', 4000, '2012-02-23', 5),
(16, 'Base', 4000, '2012-02-23', 2),
(17, 'Base', 5000, '2010-02-23', 23),
(18, 'Serun', 4000, '2012-02-23', 4),
(19, 'Serun', 200000, '2012-02-23', 56);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `banner`
--
ALTER TABLE `banner`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `categoria`
--
ALTER TABLE `categoria`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `cliente`
--
ALTER TABLE `cliente`
  ADD PRIMARY KEY (`idCliente`),
  ADD KEY `id` (`id`);

--
-- Indexes for table `detalhesproduct`
--
ALTER TABLE `detalhesproduct`
  ADD KEY `idPedido` (`idPedido`);

--
-- Indexes for table `pedido`
--
ALTER TABLE `pedido`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `idCliente` (`idCliente`);

--
-- Indexes for table `produtos`
--
ALTER TABLE `produtos`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idCategoria` (`idCategoria`);

--
-- Indexes for table `usuarios`
--
ALTER TABLE `usuarios`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `email` (`email`);

--
-- Indexes for table `venda`
--
ALTER TABLE `venda`
  ADD PRIMARY KEY (`idVenda`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `banner`
--
ALTER TABLE `banner`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;

--
-- AUTO_INCREMENT for table `categoria`
--
ALTER TABLE `categoria`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `cliente`
--
ALTER TABLE `cliente`
  MODIFY `idCliente` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;

--
-- AUTO_INCREMENT for table `pedido`
--
ALTER TABLE `pedido`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=47;

--
-- AUTO_INCREMENT for table `produtos`
--
ALTER TABLE `produtos`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=24;

--
-- AUTO_INCREMENT for table `usuarios`
--
ALTER TABLE `usuarios`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=37;

--
-- AUTO_INCREMENT for table `venda`
--
ALTER TABLE `venda`
  MODIFY `idVenda` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=20;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `cliente`
--
ALTER TABLE `cliente`
  ADD CONSTRAINT `cliente_ibfk_1` FOREIGN KEY (`id`) REFERENCES `usuarios` (`id`);

--
-- Constraints for table `detalhesproduct`
--
ALTER TABLE `detalhesproduct`
  ADD CONSTRAINT `detalhesProduct_ibfk_1` FOREIGN KEY (`idPedido`) REFERENCES `pedido` (`id`);

--
-- Constraints for table `pedido`
--
ALTER TABLE `pedido`
  ADD CONSTRAINT `pedido_ibfk_1` FOREIGN KEY (`idCliente`) REFERENCES `cliente` (`idCliente`);

--
-- Constraints for table `produtos`
--
ALTER TABLE `produtos`
  ADD CONSTRAINT `produtos_ibfk_1` FOREIGN KEY (`idCategoria`) REFERENCES `categoria` (`id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
